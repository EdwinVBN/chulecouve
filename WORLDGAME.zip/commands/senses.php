<?php require_once 'helper_functions.php'; ?>
<?php
   function look($arguments, $person, $conn) {
      /**
       * describe what the character is looking at
       */

      echo "It \033[91mlooks\033[0m like you need to code me first....\n";
   }
?>