<?php
   /**
    * helper functions support the commands but are not commands
    */
    function anywhere($whatever_you_give_me) {
      echo "... I can handle and you can reuse me everywhere\n";
    }
?>